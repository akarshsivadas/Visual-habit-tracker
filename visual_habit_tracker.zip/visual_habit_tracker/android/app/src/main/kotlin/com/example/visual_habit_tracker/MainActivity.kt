package com.example.visual_habit_tracker

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
