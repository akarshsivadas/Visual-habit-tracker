import 'package:flutter/material.dart';
import 'package:visual_habit_tracker/core/storage.dart';
import 'package:visual_habit_tracker/models/habit.dart';
import 'package:visual_habit_tracker/widgets/streak_animation.dart';
import 'package:visual_habit_tracker/screens/habit_detail_screen.dart';
import 'package:visual_habit_tracker/screens/workout_screen.dart'; // ✅ added

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Habit> habits = [];

  @override
  void initState() {
    super.initState();
    _loadHabits();
  }

  Future<void> _loadHabits() async {
    List<Habit> loaded = await Storage.loadHabits();

    if (loaded.isEmpty) {
      loaded = [
        Habit(
          id: 'water',
          label: 'Water Intake',
          emoji: '💧',
          streak: 0,
          lastCheckIn: DateTime(2000),
          dailyTarget: 8,
          currentProgress: 0,
        ),
        Habit(
          id: 'workout',
          label: 'Workout',
          emoji: '🏋️',
          streak: 0,
          lastCheckIn: DateTime(2000),
          dailyTarget: 1,
          currentProgress: 0,
        ),
        Habit(
          id: 'screen',
          label: 'Screen-Free',
          emoji: '📵',
          streak: 0,
          lastCheckIn: DateTime(2000),
          dailyTarget: 1,
          currentProgress: 0,
        ),
      ];
      await Storage.saveHabits(loaded);
    }

    setState(() => habits = loaded);
  }

  Future<void> _checkIn(Habit habit) async {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final last = DateTime(
      habit.lastCheckIn.year,
      habit.lastCheckIn.month,
      habit.lastCheckIn.day,
    );

    if (last != today) {
      habit.currentProgress = 0;
      habit.lastCheckIn = now;
    }

    if (habit.currentProgress >= habit.dailyTarget) return;

    habit.currentProgress += 1;

    if (habit.currentProgress >= habit.dailyTarget) {
      if (today.difference(last).inDays == 1) {
        habit.streak += 1;
      } else {
        habit.streak = 1;
      }
      habit.lastCheckIn = now;

      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const StreakAnimation(),
      );

      if ([3, 5, 7].contains(habit.streak)) {
        await Future.delayed(const Duration(milliseconds: 1800));
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text("🎉 ${habit.streak}-Day Streak!"),
            content: Text("You're crushing it on ${habit.label}!"),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: const Text("Nice!"),
              ),
            ],
          ),
        );
      }
    }

    setState(() {});
    await Storage.saveHabits(habits);
  }

  List<Color> _getGradientColorsForTime() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return [Colors.lightBlue.shade100, Colors.white];
    } else if (hour < 18) {
      return [Colors.orange.shade100, Colors.yellow.shade100];
    } else {
      return [Colors.indigo.shade300, Colors.black87];
    }
  }

  void _showTargetDialog(Habit habit) {
    final controller = TextEditingController(
      text: habit.dailyTarget.toString(),
    );

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text("Set Daily Target for ${habit.label}"),
        content: TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          decoration: const InputDecoration(labelText: "Target (e.g. 8)"),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              final newTarget = int.tryParse(controller.text);
              if (newTarget != null && newTarget > 0) {
                setState(() {
                  habit.dailyTarget = newTarget;
                  habit.currentProgress = 0;
                });
                Storage.saveHabits(habits);
              }
              Navigator.pop(context);
            },
            child: const Text("Save"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final quotes = [
      "One day or day one — you decide.",
      "Small steps every day.",
      "Discipline beats motivation.",
      "Progress, not perfection.",
      "Consistency > intensity.",
    ];
    final todayQuote = quotes[DateTime.now().day % quotes.length];

    return Scaffold(
      appBar: AppBar(title: const Text('Habit Tracker'), centerTitle: true),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: _getGradientColorsForTime(),
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            children: [
              Text(
                '💡 $todayQuote',
                style: const TextStyle(
                  fontSize: 16,
                  fontStyle: FontStyle.italic,
                  color: Colors.teal,
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 20),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  mainAxisSpacing: 24,
                  crossAxisSpacing: 24,
                  children: habits.map((habit) {
                    final now = DateTime.now();
                    final today = DateTime(now.year, now.month, now.day);
                    final last = DateTime(
                      habit.lastCheckIn.year,
                      habit.lastCheckIn.month,
                      habit.lastCheckIn.day,
                    );
                    final isComplete =
                        habit.currentProgress >= habit.dailyTarget;

                    return Material(
                      color: Colors.transparent,
                      child: InkWell(
                        borderRadius: BorderRadius.circular(20),
                        onTap: () async {
                          if (habit.label.toLowerCase() == "workout") {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => const WorkoutScreen(),
                              ),
                            );
                            return;
                          }

                          if (!isComplete) {
                            await _checkIn(habit);
                          } else {
                            final result = await Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => HabitDetailScreen(habit: habit),
                              ),
                            );
                            if (result == true) setState(() {});
                          }
                        },
                        onLongPress: () => _showTargetDialog(habit),
                        child: AnimatedOpacity(
                          duration: const Duration(milliseconds: 300),
                          opacity: isComplete ? 0.6 : 1.0,
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.teal.withOpacity(0.08),
                              borderRadius: BorderRadius.circular(20),
                              border: Border.all(
                                color: isComplete ? Colors.green : Colors.teal,
                                width: 1.5,
                              ),
                            ),
                            child: Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(
                                    habit.emoji,
                                    style: const TextStyle(fontSize: 40),
                                  ),
                                  const SizedBox(height: 12),
                                  Text(
                                    habit.label,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w600,
                                      color: Colors.teal.shade800,
                                    ),
                                  ),
                                  const SizedBox(height: 8),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                      horizontal: 12.0,
                                    ),
                                    child: Column(
                                      children: [
                                        LinearProgressIndicator(
                                          value:
                                              habit.currentProgress /
                                              habit.dailyTarget,
                                          minHeight: 6,
                                          backgroundColor: Colors.grey[300],
                                          valueColor:
                                              AlwaysStoppedAnimation<Color>(
                                                Colors.teal,
                                              ),
                                        ),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${habit.currentProgress}/${habit.dailyTarget}',
                                          style: const TextStyle(fontSize: 12),
                                        ),
                                      ],
                                    ),
                                  ),
                                  const SizedBox(height: 6),
                                  Text(
                                    '🔥 ${habit.streak}-day streak',
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: Colors.deepOrange,
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                  if (isComplete)
                                    const Padding(
                                      padding: EdgeInsets.only(top: 8.0),
                                      child: Icon(
                                        Icons.check_circle,
                                        color: Colors.green,
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
