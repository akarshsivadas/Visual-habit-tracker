import 'package:flutter/material.dart';
import 'package:percent_indicator/circular_percent_indicator.dart';
import '../models/habit.dart';

class HabitDetailScreen extends StatelessWidget {
  final Habit habit;

  const HabitDetailScreen({super.key, required this.habit});

  @override
  Widget build(BuildContext context) {
    double adherencePercent = habit.streak / 7;
    if (adherencePercent > 1.0) adherencePercent = 1.0;

    return Scaffold(
      appBar: AppBar(title: Text('${habit.label} Details')),
      body: Padding(
        padding: const EdgeInsets.all(30.0),
        child: Column(
          children: [
            CircularPercentIndicator(
              radius: 100.0,
              lineWidth: 15.0,
              animation: true,
              percent: adherencePercent,
              center: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(habit.emoji, style: const TextStyle(fontSize: 40)),
                  Text(
                    '${(adherencePercent * 100).toInt()}%',
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
              circularStrokeCap: CircularStrokeCap.round,
              progressColor: Colors.teal,
              backgroundColor: Colors.teal.withOpacity(0.2),
            ),
            const SizedBox(height: 30),
            Text(
              '🔥 ${habit.streak}-day streak',
              style: const TextStyle(
                fontSize: 20,
                color: Colors.deepOrange,
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 30),
            ElevatedButton.icon(
              onPressed: () {
                Navigator.pop(context, true); // tell home screen to refresh
              },
              icon: const Icon(Icons.arrow_back),
              label: const Text('Back to Habits'),
            ),
          ],
        ),
      ),
    );
  }
}
