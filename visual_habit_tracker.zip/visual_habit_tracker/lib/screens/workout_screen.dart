import 'dart:async';
import 'package:flutter/material.dart';

class WorkoutScreen extends StatefulWidget {
  const WorkoutScreen({super.key});

  @override
  State<WorkoutScreen> createState() => _WorkoutScreenState();
}

class _WorkoutScreenState extends State<WorkoutScreen> {
  final List<Map<String, dynamic>> allWorkouts = [
    {'name': 'Jumping Jacks', 'duration': 30, 'equipment': []},
    {'name': 'Plank', 'duration': 45, 'equipment': []},
    {
      'name': 'Push-ups',
      'duration': 30,
      'equipment': ['Mat'],
    },
    {'name': 'Squats', 'duration': 30, 'equipment': []},
    {
      'name': 'Dumbbell Curl',
      'duration': 30,
      'equipment': ['Dumbbells'],
    },
  ];

  final List<String> availableEquipment = [];
  int currentIndex = 0;
  int timeLeft = 0;
  Timer? _timer;

  List<Map<String, dynamic>> get filteredWorkouts {
    return allWorkouts.where((exercise) {
      for (final eq in exercise['equipment']) {
        if (!availableEquipment.contains(eq)) return false;
      }
      return true;
    }).toList();
  }

  void startExercise() {
    if (currentIndex >= filteredWorkouts.length) return;

    setState(() {
      timeLeft = filteredWorkouts[currentIndex]['duration'];
    });

    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        timeLeft--;
        if (timeLeft == 0) {
          timer.cancel();
          nextExercise();
        }
      });
    });
  }

  void nextExercise() {
    if (currentIndex < filteredWorkouts.length - 1) {
      setState(() {
        currentIndex++;
      });
      startExercise();
    } else {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text("Workout Complete!"),
          content: const Text("Great job finishing your session!"),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // close dialog
                Navigator.pop(context); // go home
              },
              child: const Text("Back to Home"),
            ),
          ],
        ),
      );
    }
  }

  void skipExercise() {
    _timer?.cancel();
    nextExercise();
  }

  void toggleEquipment(String item) {
    setState(() {
      if (availableEquipment.contains(item)) {
        availableEquipment.remove(item);
      } else {
        availableEquipment.add(item);
      }
      currentIndex = 0;
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final workouts = filteredWorkouts;
    final currentExercise = workouts.isNotEmpty ? workouts[currentIndex] : null;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Workout Session"),
        actions: [
          IconButton(
            icon: const Icon(Icons.home),
            onPressed: () => Navigator.pop(context),
          ),
        ],
      ),
      body: workouts.isEmpty
          ? const Center(child: Text("No workouts match your equipment."))
          : Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Wrap(
                    spacing: 10,
                    children: ['Mat', 'Dumbbells'].map((e) {
                      final selected = availableEquipment.contains(e);
                      return FilterChip(
                        label: Text(e),
                        selected: selected,
                        onSelected: (_) => toggleEquipment(e),
                      );
                    }).toList(),
                  ),
                  const SizedBox(height: 20),
                  Text(
                    currentExercise!['name'],
                    style: const TextStyle(fontSize: 32),
                  ),
                  const SizedBox(height: 10),
                  Text(
                    "Time Left: $timeLeft sec",
                    style: const TextStyle(fontSize: 20),
                  ),
                  const SizedBox(height: 30),
                  ElevatedButton(
                    onPressed: startExercise,
                    child: const Text("Start"),
                  ),
                  const SizedBox(height: 10),
                  ElevatedButton(
                    onPressed: skipExercise,
                    child: const Text("Skip"),
                  ),
                ],
              ),
            ),
    );
  }
}
