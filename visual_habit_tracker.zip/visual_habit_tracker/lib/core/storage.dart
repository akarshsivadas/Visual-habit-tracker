import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/habit.dart';

class Storage {
  static const _key = 'habit_data';

  static Future<List<Habit>> loadHabits() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(_key);
    if (data == null) return [];

    final List<dynamic> decoded = json.decode(data);
    return decoded.map((e) => Habit.fromJson(e)).toList();
  }

  static Future<void> saveHabits(List<Habit> habits) async {
    final prefs = await SharedPreferences.getInstance();
    final encoded = json.encode(habits.map((e) => e.toJson()).toList());
    await prefs.setString(_key, encoded);
  }
}
