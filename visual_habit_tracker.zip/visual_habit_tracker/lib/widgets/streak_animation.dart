import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class StreakAnimation extends StatelessWidget {
  const StreakAnimation({super.key});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.transparent,
      elevation: 0,
      content: Lottie.asset(
        'assets/animations/success.json',
        repeat: false,
        onLoaded: (composition) {
          Future.delayed(composition.duration, () {
            Navigator.of(context).pop();
          });
        },
      ),
    );
  }
}
