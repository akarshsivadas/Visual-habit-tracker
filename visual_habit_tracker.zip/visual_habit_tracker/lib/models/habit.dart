class Habit {
  final String id;
  final String label;
  final String emoji;
  int streak;
  DateTime lastCheckIn;

  int dailyTarget; // 👈 Add this
  int currentProgress; // 👈 And this

  Habit({
    required this.id,
    required this.label,
    required this.emoji,
    required this.streak,
    required this.lastCheckIn,
    required this.dailyTarget,
    required this.currentProgress,
  });

  factory Habit.fromJson(Map<String, dynamic> json) {
    return Habit(
      id: json['id'],
      label: json['label'],
      emoji: json['emoji'],
      streak: json['streak'],
      lastCheckIn: DateTime.parse(json['lastCheckIn']),
      dailyTarget: json['dailyTarget'] ?? 1,
      currentProgress: json['currentProgress'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'label': label,
      'emoji': emoji,
      'streak': streak,
      'lastCheckIn': lastCheckIn.toIso8601String(),
      'dailyTarget': dailyTarget,
      'currentProgress': currentProgress,
    };
  }
}
